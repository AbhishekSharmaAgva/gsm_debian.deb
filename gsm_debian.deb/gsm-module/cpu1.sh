#!/bin/bash

while true 

do

date >> /home/agva/service.py

sudo du -sch / >> /home/agva/service.py

sleep 120

done
