
import serial
import RPi.GPIO as GPIO
import os, time
def getserial():
		cpuserial = 0
	#	cpuserial = '000000007cab00e5'
#	try:
		f = open('/proc/cpuinfo','r')
		for line in f:
#			print line
			if line[0:6]=='Serial':
#				print "Serial"
#				print(line[10:26])
				cpuserial = line[10:26]
			#	print cpuserial
				f.close()
				return cpuserial
				exit()
	#	print cpuserial
#	except:
	#	cpuserial = 'ERROR000000000'
#	print("key")
		return 0
#print(getserial())
#key = getserial()
#print(key)
#	 GPIO.setmode(GPIO.BOARD)

#	 port = serial.Serial("/dev/ttyS0", baudrate=9600, timeout=1)

if getserial()=="000000007cab00e5":
	print('key1')
	print('cpu found')
	GPIO.setmode(GPIO.BOARD)

# Enable Serial Communication
	port = serial.Serial("/dev/ttyS0", baudrate=9600, timeout=1)

# Transmitting AT Commands to the Modem
# '\r\n' indicates the Enter key
	str = chr(26)
	while 1:

		port.write('AT'+'\r\n')
		rcv = port.read(128)
		print rcv
		time.sleep(0.1)

		port.write('AT+CPIN?\r\n')      # Disable the Echo
		rcv = port.read(128)
		print rcv
		time.sleep(0.1)

		port.write('AT+CREG?\r\n')      # Disable the Echo
		rcv = port.read(128)
		print rcv
		time.sleep(0.1)

		port.write('AT+CGATT?\r\n')      # Disable the Echo
		rcv = port.read(128)
		print rcv
		time.sleep(0.1)

		port.write('AT+CIPSHUT\r\n')  # Select Message format as Text mode 
		rcv = port.read(128)
		print rcv
		time.sleep(0.1)
 
		port.write('AT+CIPSTATUS\r\n')      # Disable the Echo
		rcv = port.read(128)
		print rcv
		time.sleep(0.1)

		port.write('AT+CIPMUX=0\r\n')   # New SMS Message Indications
		rcv = port.read(128)
		print rcv
		time.sleep(0.1)
 
# Sending a message to a particular Number
#	port.write("AT+CGDCONT=1"+","+'"IP"'+","'"airtelgprs.com"\r')
#	rcv = port.read(128)
#	print rcv
#	time.sleep(1)

		port.write('AT+CSTT="airtelgprs.com"\r\n')
		rcv = port.read(128)
		print rcv
		time.sleep(0.1)

		port.write('AT+CIICR\r\n')      # Disable the Echo
		rcv = port.read(128)
		print rcv
		time.sleep(0.1)

		port.write('AT+CIFSR\r\n')      # Disable the Echo
		rcv = port.read(128)
		print rcv
		time.sleep(0.1)

		port.write('AT+CIPSTATUS\r\n')      # Disable the Echo
		rcv = port.read(128)
		print rcv
		time.sleep(0.1)

		port.write('AT+CIPSTART="TCP","api.thingspeak.com","80"\r\n')      # Disable the Echo
#	time.sleep(0.3)
		rcv = port.read(128)
		print rcv
		time.sleep(3)

#	port.write('AT+HTTPINIT\r\n')      # Disable the Echo
#	time.sleep(1)
#	rcv = port.read(128)
#	print rcv
#	time.sleep(0.3)


		x='GET https://api.thingspeak.com/update?api_key=FVTA8D044KOWOM7C&field1=10\r\n'
		port.write('AT+CIPSEND\r\n')  # + x +'#026\r')      # Disable the Echo
		rcv = port.read(128)
		print rcv
		time.sleep(0.1)
		port.write(x)
		rcv = port.read(128)
		print rcv
		port.write(str.encode())
		rcv = port.read(128)
		print rcv
 
#	x='GET https://api.thingspeak.com/update?api_key=FVTA8D044KOWOM7C&field1=5000'
		port.write('AT+CIPCLOSE=1'+'\r\n')      # Disable the Echo
		rcv = port.read(128)
		print rcv
        	time.sleep(0.1)

#	x='GET https://api.thingspeak.com/update?api_key=FVTA8D044KOWOM7C&field1=5000'
		port.write('AT+CIPSHUT'+'\r\n')      # Disable the Echo
		rcv = port.read(128)
		print rcv
        	time.sleep(0.1)

else:
	print("error")
	port = serial.Serial("/dev/ttyS0", baudrate=9600, timeout=1)

	port.write('AT'+'\r\n')
	rcv = port.read(10)
	print rcv
	time.sleep(1)
 
	port.write('ATE0'+'\r\n')      # Disable the Echo
	rcv = port.read(10)
	print rcv
	time.sleep(1)
 
	port.write('AT+CMGF=1'+'\r\n')  # Select Message format as Text mode 
	rcv = port.read(10)
	print rcv
	time.sleep(1)
 
	port.write('AT+CNMI=2,1,0,0,0'+'\r\n')   # New SMS Message Indications
	rcv = port.read(10)
	print rcv
	time.sleep(1)
 
# Sending a message to a particular Number
 
	port.write('AT+CMGS="7838434761"'+'\r\n')
	rcv = port.read(10)
	print rcv
	time.sleep(1)
 
	port.write('error you putted the wrong raspberry pi'+'\r\n')  # Message
	rcv = port.read(10)
	print rcv
 
	port.write("\x1A") # Enable to send SMS
	for i in range(10):
		rcv = port.read(10)
		print rcv
